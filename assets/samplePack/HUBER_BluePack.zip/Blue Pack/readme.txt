I hope you'll enjoy this royalty free sample pack
Guitar samples recorded on my Fender Telecaster

Two more packs to come soon ! 
Feel free to hit me up on social media (@huber_lofiandchill) and to show some love on Spotify :)
